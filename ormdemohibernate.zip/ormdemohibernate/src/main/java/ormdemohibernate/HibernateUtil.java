package ormdemohibernate;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HibernateUtil
{
	private static SessionFactory sessionFactory;
	
	public static SessionFactory getSessionFactory()
	{
		if(sessionFactory==null)
		{
			try
			{
			y	Configuration configuration =new Configuration();
				configuration.configure().addAnnotatedClass(Student.class);
				ServiceRegistry serviceRegistry=new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
				sessionFactory =configuration.buildSessionFactory(serviceRegistry);
				
			}
			catch (Exception e )
			{
				e.printStackTrace();
			}
		}
		return sessionFactory;
		
	}
	
	
	

}
