package ormdemohibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class StudentDao implements IStudentDao 
{
	public void saveStudent(Student student)
	{
		Transaction transaction= null;
		Session session=HibernateUtil.getSessionFactory().openSession();
		transaction=session.beginTransaction();
		session.save(student);
		transaction.commit();	
	}

	public void updateStudent(Student student)
	{
		// TODO Auto-generated method stub
		Transaction transaction= null;
		Session session=HibernateUtil.getSessionFactory().openSession();
		transaction=session.beginTransaction();
		session.saveOrUpdate(student);
		transaction.commit();	
	}

	public Student getStudentById(int id) 
	{
		// TODO Auto-generated method stub
		Transaction transaction= null;
		Student student =null;
		Session session=HibernateUtil.getSessionFactory().openSession();
		transaction=session.beginTransaction();
	    student = (Student)session.get(Student.class, id);
		transaction.commit();
		return student;
	}
@SuppressWarnings("unchecked")
	public List<Student> getAllStudents()
	{
		// TODO Auto-generated method stub
		Transaction transaction= null;
		List<Student> students=null;
		Session session=HibernateUtil.getSessionFactory().openSession();
		transaction=session.beginTransaction();
	    students =session.createQuery("from Student").list(); //Student is java class name -it doesnot refer the db.
		return students;
	}
	public void deleteStudent(int id)
	{
		// TODO Auto-generated method stub
		Transaction transaction= null;
		Student student =null;
		Session session=HibernateUtil.getSessionFactory().openSession();
		transaction=session.beginTransaction();
	    student = (Student)session.get(Student.class, id);
	    session.delete(student);
		transaction.commit();
	}

}
